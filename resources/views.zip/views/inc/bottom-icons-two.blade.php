<section class="bottom-icons2">
    <div class="container">
        <div class="row">
        <div class="col-md-12 bottom-icons2-heading">
            Our Hotel
        </div>
        <div class="col-md-2 bottom-icons2-div">
            <div class="bottom-icons2-div-icon">
            <i class="fab fa-atlassian"></i>
            </div>
            <div class="bottom-icons2-div-text1">FREE BREAKFAST FOR MEMBERS</div>
        </div>
        <div class="col-md-2 bottom-icons2-div">
            <div class="bottom-icons2-div-icon">
            <i class="fab fa-atlassian"></i>
            </div>
            <div class="bottom-icons2-div-text1">When you book</div>
        </div>
        <div class="col-md-2 bottom-icons2-div">
            <div class="bottom-icons2-div-icon">
            <i class="fab fa-atlassian"></i>
            </div>
            <div class="bottom-icons2-div-text1">FITNESS CENTER</div>
        </div>
        <div class="col-md-2 bottom-icons2-div">
            <div class="bottom-icons2-div-icon">
            <i class="fab fa-atlassian"></i>
            </div>
            <div class="bottom-icons2-div-text1">ROOM SERVICE</div>
        </div>
        <div class="col-md-2 bottom-icons2-div">
            <div class="bottom-icons2-div-icon">
            <i class="fab fa-atlassian"></i>
            </div>
            <div class="bottom-icons2-div-text1">FREE BREAKFAST FOR MEMBERS</div>
        </div>
        <div class="col-md-2 bottom-icons2-div">
            <div class="bottom-icons2-div-icon">
            <i class="fab fa-atlassian"></i>
            </div>
            <div class="bottom-icons2-div-text1">When you book</div>
        </div>
        </div>
    </div>
</section>