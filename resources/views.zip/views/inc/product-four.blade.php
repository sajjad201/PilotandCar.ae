<section class="pr-4-sec">
    <div class="container">
        <div class="col-md-12 col-xs-12 pr-4-sec-head-txt">
            DESTINATION INFORMATION
            <div class="pr-4-sec-head-txt-2">
                Getting familiar with your destinations information to make your dream trip complete.
            </div>    
        </div>
        <div class="row">
            @for ($i = 0; $i < 6; $i++)
            <div class="col-md-4 col-xs-12 pr-4-img-div-col" style="padding:15px">
                <div class="col-xs-12 pr-4-img-div">
                    <div>
                        <img src="pilotpublic/images/8.jpg" style="height:250px; width:100%">
                    </div>
                    <div class="col-xs-12 pr-4-img-div-txt">
                        BOOK YOUR RIDE:
                        <div class="row" style="margin-top:10px">
                            <div class="col-md-6 col-xs-6" style="padding:0px">
                                <div class="pr-4-img-div-txt-row-txt"> PER HOUR</div>
                                <div class="pr-4-prices">499 AED</div>
                            </div>
                            <div class="col-md-6 col-xs-6" style="padding:0px">
                                <div class="pr-4-img-div-txt-row-txt" style="border-left:1px solid white; ">PER DAY</div>
                                <div class="pr-4-prices" style="border-left:1px solid white; ">$599</div>
                            </div>
                        </div>
                        
                    
                    </div>
                </div>
            </div>
            @endfor
        </div>
    </div>
</section>