<section class="mt-20" style="padding:30px 0px 100px;">
    <div class="container">
      <div class="row">
        <div class="col-md-12" style="padding:0px 5px;">
          <div class="st10-split-text">
            CHECK OUR PRODUCTS
          </div>
        </div>
        <div class="product-cnt">
          <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMScontent/web/SiteCollectionImages/06-Destinations-World/Bangkok/BKK-floating-market-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMScontent/web/SiteCollectionImages/06-Destinations-World/Los-Angeles/los-angeles-06-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMSContent/web/SiteCollectionImages/05-Destinations-Europe/Moscow/Moscow-02-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
                  <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMScontent/web/SiteCollectionImages/02-Inflight/inflight-couple-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
                  <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMSContent/web/SiteCollectionImages/05-Destinations-Europe/Barcelona/barcelona-01-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 mb-5">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMSContent/web/SiteCollectionImages/05-Destinations-Europe/Moscow/Moscow-02-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>