<style>
.wrapper {
  margin:0px;
}
</style>
<section class="wrapper os-2-wrap" style="color:#313131; background-color:#f2f2f2; padding:60px 0px 60px 0px">
  <div class="container">
    <div class="col-md-12"><h1 style="color:#034F84"><strong>BOOK RIDES NOW<br><br></strong></h1></div>
    @for ($i = 0; $i < 5; $i++)
      <div class="col-md-4" style="margin-bottom: 30px;">
        <div class="os-2-cont">
          <div class="os-2-img-cont rel">
            <img src="pilotpublic/images/12.jpg" style="height:200px; width:100%">
            <h3 class="abs-head">Hong Kong SAR </h3>
            <span class="fa fa-star abs-icon"></span>
          </div>
          <div class="os2-txt-cont">
            <div class="overlay1">
              <span class="overlay1-txt"> BOOK HOURLY RIDE</span>
              <i class="fas fa-car overlay1-txt-icon" style="margin-left:25px"></i>
            </div>
            <div>Economy Form</div>
            <div class="os2-h3">AED 950 <span class="fa fa-angle-right fl-right fs-20"></span></div>
          </div>
          <div class="os2-txt-cont" style="border-top:5px solid #f9f9f9">
              <div class="overlay1">
                <span class="overlay1-txt">BOOK PER DAY RIDE</span>
                <i class="fas fa-shuttle-van overlay1-txt-icon" style="margin-left:25px"></i>
              </div>
              <div>Economy Form</div>
              <div class="os2-h3">AED 950 <span class="fa fa-angle-right fl-right fs-20"></span></div>
            </div>
        </div>
      </div>
    @endfor
  </div>
</section>
     