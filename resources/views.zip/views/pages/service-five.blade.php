
@extends('layouts.app-two')

@section('page_title')
    SERVICE TEN
@endsection

@section('content')

<section>
  <div style="position:relative">
    <img src="pilotpublic/images/19.jpg">
    <div style="position:absolute; left:5%; top:25%">
      <h1 style="text-shadow: 1px 1px 7px black; color:white; font-size:50px">
        <strong>THIS IS THE TEXT</strong>
      </h1>
    <div>
  </div>
</section>
<section class="page-nav-links">
  <div class="container">
    <div class="row">
      <div class="col-md-12 page-nav-links-col">
        <div class="col-md-1 page-nav-links-col-internal">Home <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Serives<i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Service One <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal-current">Current Page</div>
      </div>
    </div>
  </div>
</section>
<br><br><br><br>


<section>
    <div class="container">
      <div class="row os-10-shadow">
        <div class="col-md-12" style="text-align:center">
          <div>
            <h1>
              <strong>
                  WHERE'S YOUR NEXT ADVENTURE?​
              </strong>
            </h1>
            <h5>
                Explore the world, one city at a time.  <br><br><br><br>
            </h5>
          </div>
        </div>

        
        
        <div class="col-md-6">
          <div class="col-md-12 mb-20 pr-0">
          <div class="os10-cnt">
            <div class="col-md-6 pr-0">
              <div class="os-10-txt">
                <h3 style="margin-top: 0;">3 of world's most popular structures</h3>
                <p class="os10-p">Fot that perfect holiday, take your partner on a trip to 3 of these great monuments of love around the world.</p>
              </div>
            </div>
            <div class="col-md-6 pl-0 pr-0">
              <div class="os10-img-cnt">
                <img src="pilotpublic/images/12.jpg" class="img-fluid">
              </div>
            </div>
          </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="col-md-12 mb-20 pr-0">
          <div class="os10-cnt">
            <div class="col-md-6 pr-0">
              <div class="os-10-txt">
                <h3 style="margin-top: 0;">3 of world's most popular structures</h3>
                <p class="os10-p">Fot that perfect holiday, take your partner on a trip to 3 of these great monuments of love around the world.</p>
              </div>
            </div>
            <div class="col-md-6 pl-0 pr-0">
              <div class="os10-img-cnt">
                <img src="pilotpublic/images/os81.jpg" class="img-fluid">
              </div>
            </div>
          </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="col-md-12 mb-20 pr-0">
          <div class="os10-cnt">
            <div class="col-md-6 pr-0">
              <div class="os-10-txt">
                <h3 style="margin-top: 0;">3 of world's most popular structures</h3>
                <p class="os10-p">Fot that perfect holiday, take your partner on a trip to 3 of these great monuments of love around the world.</p>
              </div>
            </div>
            <div class="col-md-6 pl-0 pr-0">
              <div class="os10-img-cnt">
                <img src="pilotpublic/images/9.jpg" class="img-fluid">
              </div>
            </div>
          </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="col-md-12 mb-20 pr-0">
          <div class="os10-cnt">
            <div class="col-md-6 pr-0">
              <div class="os-10-txt">
                <h3 style="margin-top: 0;">3 of world's most popular structures</h3>
                <p class="os10-p">Fot that perfect holiday, take your partner on a trip to 3 of these great monuments of love around the world.</p>
              </div>
            </div>
            <div class="col-md-6 pl-0 pr-0">
              <div class="os10-img-cnt">
                <img src="pilotpublic/images/10.jpg" class="img-fluid">
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </section>

@include('inc.product-five')
@include('inc.text-three')  

<br><br><br><br><br>
  <section>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12" style="padding:0px">
            <div style="background-color: #fbfbfb; text-align:center">
                <br><br>
                <h1><strong> PLANNING FOR YOUR TRIP</strong></h1>
          
                <div class="container link-card__card-container link-card__card-container-mb ">
                      
                    <a href="https://www.booking.com/index.html?aid=1183184" target="_blank" class="context-item link-card__item hover--move-up">
                        <div class="icon-container">
                            <i class="img-icon icon-new-hotel"><i class="fab fa-angular" style="font-size:30px"></i></i>
                        </div>
                        <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                            Book Hotels
                        </div>
                    </a>
                
                    <a href="http://www.changiairport.com/en/airport-guide/facilities-and-services/transit-hotels.html" class="context-item link-card__item hover--move-up">
                        <div class="icon-container">
                            <i class="img-icon icon-new-transit_hotel"><i class="fab fa-angular" style="font-size:30px"></i></i>
                        </div>
                        <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                            Transit Hotels
                        </div>
                    </a>
                
                    <a href="https://www.rentalcars.com/?affiliateCode=changiairport" target="_blank" class="context-item link-card__item hover--move-up">
                        <div class="icon-container">
                            <i class="img-icon icon-new-driving"><i class="fab fa-angular" style="font-size:30px"></i></i>
                        </div>
                        <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                            Rent a Car
                        </div>
                    </a>
                
                    <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
                        <div class="icon-container">
                            <i class="img-icon icon-new-get_connected_in_sg"><i class="fab fa-angular" style="font-size:30px"></i></i>
                        </div>
                        <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                            Rent a WiFi Router
                        </div>
                    </a>
                    <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
                      <div class="icon-container">
                          <i class="img-icon icon-new-get_connected_in_sg"><i class="fab fa-angular" style="font-size:30px"></i></i>
                      </div>
                      <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                          Rent a WiFi Router
                      </div>
                  </a>
                  <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
                    <div class="icon-container">
                        <i class="img-icon icon-new-get_connected_in_sg"><i class="fab fa-angular" style="font-size:30px"></i></i>
                    </div>
                    <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                        Rent a WiFi Router
                    </div>
                </a>
          
          
                
            </div>
          </div>
        </div>
        <div class="col-md-6" style="padding:0px">
          <img src="pilotpublic/images/7.jpg" style="height:500px">
        </div>
        <div class="col-md-6 st-icons-class">
          <ul class="st-icons-ul">
              <li><i class="fab fa-asymmetrik st-icons-style"></i><span class="st-icons-hover">FLIGHTS</span></li><br>
              <li><i class="fas fa-atlas st-icons-style"></i><span class="st-icons-hover">DEPARTURE FLIGHTS</span></li><br>
              <li><i class="fab fa-angular st-icons-style"></i><span class="st-icons-hover">AIRLINE INFORMATION</span></li><br>
              <li><i class="fas fa-atlas st-icons-style"></i><span class="st-icons-hover">FLIGHT PLANNER</span></li><br>
              <li><i class="fas fa-band-aid st-icons-style"></i><span class="st-icons-hover">SPECIAL ASSISTANCE</span></li><br>
              <li><i class="fas fa-atlas st-icons-style"></i><span class="st-icons-hover">DEPARTURE FLIGHTS</span></li><br>
          </ul>
        </div>
      </div>
    </div>
  </section>
   
@include('inc.bottom-icons-two')  
@endsection




