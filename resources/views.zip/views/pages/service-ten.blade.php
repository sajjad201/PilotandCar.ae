
@extends('layouts.app-two')

@section('page_title')
    SERVICE TEN
@endsection

@section('content')



<section>
  <div style="position: relative; color:white">
    <img src="pilotpublic/images/18.jpg">
    <div style="position: absolute; top:35%; left:25%; color:white; font-size:60px; font-weight:900">OFFERS FROM PILOT & CAR</div>
  </div>
</section>
<section class="page-nav-links">
  <div class="container">
    <div class="row">
      <div class="col-md-12 page-nav-links-col">
        <div class="col-md-1 page-nav-links-col-internal">Home <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Serives<i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Service One <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal-current">Current Page</div>
      </div>
    </div>
  </div>
</section>

<br><br><br>
<section class="st-em">
  <div class="container st-em-con">
    <div class="row">
      <div class="col-md-6 st-em-col" style="padding:0px 5px">
        <div class="st-em-col-one">
          <div class="st-em-col-one-text">
            <div class="st-em-col-small-text" style="padding:0px 0px">Flying as it should be</div>
            The Emirates<br>A380
          </div>
          <img src="https://c.ekstatic.net/ecl/aircraft-exterior/airbus-A380/a380-on-the-runway-d600.jpg?h=fNksKUzMuvSi9csL1NrQ8A" style="width:100%; margin-top: -1rem;">
        </div>
      </div>
      <div class="col-md-6 st-em-col">
        <div class="row">
          <div class="col-md-6" style="padding:0px 5px">
            <div class="st-em-col-two">
              <div class="st-em-col-two-text">
                <div class="st-em-col-small-text">A Journey of Distinction</div>
                The Emirates A380
              </div>
              <img src="https://c.ekstatic.net/ecl/emirates-staff/ground-staff/emirates-staff-infront-of-home-checkin-van-600x400.jpg?h=3h0bSHrZ-yeGEmqa5iyXOQ" style="width:100%; height:100%">
            </div>
          </div>
          <div class="col-md-6" style="padding:0px 5px">
            <div class="st-em-col-two">
              <div class="st-em-col-two-text">
                <div class="st-em-col-small-text">Check in Your Bags from Home</div>
                The Emirates A380
              </div>
              <img src="https://c.ekstatic.net/ecl/emirates-staff/ground-staff/emirates-staff-infront-of-home-checkin-van-600x400.jpg?h=3h0bSHrZ-yeGEmqa5iyXOQ" style="width:100%; height:100%">
          </div>
        </div>
        <div class="row">
            <div class="col-md-6" style="padding:10px 5px">
              <div class="st-em-col-two">
                <div class="st-em-col-two-text">
                  <div class="st-em-col-small-text">Causine That Takes you places</div>
                  The Emirates A380
                </div>
                <img src="https://c.ekstatic.net/ecl/emirates-staff/ground-staff/emirates-staff-infront-of-home-checkin-van-600x400.jpg?h=3h0bSHrZ-yeGEmqa5iyXOQ" style="width:100%; height:100%">
              </div>
            </div>
            <div class="col-md-6" style="padding:10px 5px">
              <div class="st-em-col-two">
                <div class="st-em-col-two-text">
                  <div class="st-em-col-small-text">Your Window into new world</div>
                  The Emirates A380
                </div>
                <img src="https://c.ekstatic.net/ecl/emirates-staff/ground-staff/emirates-staff-infront-of-home-checkin-van-600x400.jpg?h=3h0bSHrZ-yeGEmqa5iyXOQ" style="width:100%; height:100%">
            </div>
          </div>  

        </div>
        
      </div>
    </div>
  </div>
</section>

{{-- <section>
  <div class="container" style="padding:0px;">
    <div class="row">
      <div class="col-md-12" style="padding:0px 5px;">
        <div class="st10-split-text">
          THE PILOT AND CAR SERVICES
        </div>
      </div>
      <div class="row">
        <div class="col-lg-8 st-ten-cards-one" style="padding:0px 5px;">
          <img src="pilotpublic/images/7.jpg" style="height:100%; width:100%; border-radius:3px">
          <div class="st-ten-cards-one-text1">
            Singapur Airline Holidays<br> Enjoy Great Flighs
          </div>
        </div>
        <div class="col-md-4 st-ten-cards-two" style="padding:0px 5px;">
          <img src="pilotpublic/images/8.jpg" style="height:70%; width:100%; border-radius:1px">
          <div class="st-ten-cards-one-text2">
            Singapur Airline Holidays<br> <span style="font-size:14px;"> Great Flighs</span>
          </div>
        </div>
      </div>  
      
      <div class="row" style="margin-top:10px">
        <div class="col-md-4 st-ten-cards-two" style="padding:0px 5px;">
          <img src="pilotpublic/images/9.jpg" style="height:70%; width:100%; border-radius:1px">
          <div class="st-ten-cards-one-text2">
            Singapur Airline Holidays<br> <span style="font-size:14px;"> Great Flighs</span>
          </div>
        </div>
        <div class="col-lg-8 st-ten-cards-one" style="padding:0px 5px;">
          <img src="pilotpublic/images/10.jpg" style="height:100%; width:100%; border-radius:3px">
          <div class="st-ten-cards-one-text1">
            Singapur Airline Holidays<br> Enjoy Great Flighs
          </div>
        </div>
      </div>       
    </div>
  </div>
 
<br><br><br> --}}

  <div class="container-fluid">
    <div class="st-ten-inf">
      <div class="row">
        <div class="col-md-7">
          <img src="pilotpublic/images/12.jpg" style="height:500px; width:100%; border-radius:1px">
        </div>
        <div class="col-md-5 st-ten-inf-col5">
            <h1><strong> CATERING</strong></h1>
            <h4> winning flavors in the skies</h4>
            Throughout your comfortable journey in Business Class, 
            our flying chefs will present you with the finest examples 
            of Turkish and world cuisine, served up on stylish porcelain 
            tableware. In Business Class, we make sure that your trip is 
            also a journey of tastes, with our award-winning dining on board 
            service, which is prepared by Turkish Do&Co.
        </div>
      </div>
      </div>
  </div>
</section>

<br><br><br>
@include('inc.product-one')
<br><br><br>

  @include('inc.text-two')

  <section class="wrapper os4-wrapper" style="padding:50px 0px 70px 0px ">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="os4-wrap">
              <div class="os4-img-cnt">
                <img src="pilotpublic/images/9.jpg" style="height:300px">
              </div>
              <div class="os4-txt-cnt">
                <h6 class="text-center">Italy</h6>
                <h1 style="color:#333333">Rome One</h1>
                <h5 class="">Discover for yourself</h5>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="os4-wrap">
              <div class="os4-img-cnt">
                <img src="pilotpublic/images/8.jpg" style="height:300px">
              </div>
              <div class="os4-txt-cnt">
                <h6 class="text-center">Italy</h6>
                <h1 style="color:#333333">Rome Two</h1>
                <h5 class="">Discover for yourself</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  
  <section style="margin:50px 0px 100px 0px">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            
            <div class="col-md-12" style="text-align:center; font-size:40px; color:#333333; margin:50px 0px 50px 0px">
              Check out other services
            </div>
              <span class="em-box">
              <i class="fab fa-angular" style="font-size:40px;"></i><br>
               Hotels
                <div class="em-box-border">
                  <div class="em-box-border-inner"></div>
                </div>
              </span><span class="em-box">
                  <i class="fab fa-angular" style="font-size:40px;"></i><br>
                   Hotels 
                    <div class="em-box-border">
                      <div class="em-box-border-inner"></div>
                    </div>
                  </span><span class="em-box">
                      <i class="fab fa-angular" style="font-size:40px;"></i><br>
                       Hotels
                        <div class="em-box-border">
                          <div class="em-box-border-inner"></div>
                        </div>
                      </span><span class="em-box">
                          <i class="fab fa-angular" style="font-size:40px;"></i><br>
                           Hotels
                            <div class="em-box-border">
                              <div class="em-box-border-inner"></div>
                            </div>
                          </span><span class="em-box">
                              <i class="fab fa-angular" style="font-size:40px;"></i><br>
                               Hotels
                                <div class="em-box-border">
                                  <div class="em-box-border-inner"></div>
                                </div>
                              </span><span class="em-box">
                                  <i class="fab fa-angular" style="font-size:40px;"></i><br>
                                   Hotels
                                    <div class="em-box-border">
                                      <div class="em-box-border-inner"></div>
                                    </div>
                                  </span><span class="em-box">
                                      <i class="fab fa-angular" style="font-size:40px;"></i><br>
                                       Hotels
                                        <div class="em-box-border">
                                          <div class="em-box-border-inner"></div>
                                        </div>
                                      </span><span class="em-box">
                                          <i class="fab fa-angular" style="font-size:40px;"></i><br>
                                           Hotels
                                            <div class="em-box-border">
                                              <div class="em-box-border-inner"></div>
                                            </div>
                                          </span>
            
          </div>
        </div>
      </div>
    </section>
@include('inc.bottom-icons-one')      
    
@endsection




