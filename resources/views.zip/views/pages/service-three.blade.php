
@extends('layouts.app-two')

@section('page_title')
    SERVICE THREE
@endsection

@section('content')

<section>
  <div style="position:relative">
    <img src="pilotpublic/images/19.jpg">
    <div style="position:absolute; left:5%; top:25%">
      <h1 style="text-shadow: 1px 1px 7px black; color:white; font-size:50px">
        <strong>THIS IS THE TEXT</strong>
      </h1>
    <div>
  </div>
</section>
<section class="page-nav-links">
  <div class="container">
    <div class="row">
      <div class="col-md-12 page-nav-links-col">
        <div class="col-md-1 page-nav-links-col-internal">Home <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Serives<i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Service One <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal-current">Current Page</div>
      </div>
    </div>
  </div>
</section>

@include('inc.text-three')
@include('inc.product-two')
@include('inc.text-two')

<section style="margin:50px 0px 100px 0px">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            
            <div class="col-md-12" style="text-align:center; font-size:40px; color:#333333; margin:50px 0px 50px 0px">
              Check out other services
            </div>
              <span class="em-box">
              <i class="fab fa-angular" style="font-size:40px;"></i><br>
               Hotels
                <div class="em-box-border">
                  <div class="em-box-border-inner"></div>
                </div>
              </span><span class="em-box">
                  <i class="fab fa-angular" style="font-size:40px;"></i><br>
                   Hotels 
                    <div class="em-box-border">
                      <div class="em-box-border-inner"></div>
                    </div>
                  </span><span class="em-box">
                      <i class="fab fa-angular" style="font-size:40px;"></i><br>
                       Hotels
                        <div class="em-box-border">
                          <div class="em-box-border-inner"></div>
                        </div>
                      </span><span class="em-box">
                          <i class="fab fa-angular" style="font-size:40px;"></i><br>
                           Hotels
                            <div class="em-box-border">
                              <div class="em-box-border-inner"></div>
                            </div>
                          </span><span class="em-box">
                              <i class="fab fa-angular" style="font-size:40px;"></i><br>
                               Hotels
                                <div class="em-box-border">
                                  <div class="em-box-border-inner"></div>
                                </div>
                              </span><span class="em-box">
                                  <i class="fab fa-angular" style="font-size:40px;"></i><br>
                                   Hotels
                                    <div class="em-box-border">
                                      <div class="em-box-border-inner"></div>
                                    </div>
                                  </span><span class="em-box">
                                      <i class="fab fa-angular" style="font-size:40px;"></i><br>
                                       Hotels
                                        <div class="em-box-border">
                                          <div class="em-box-border-inner"></div>
                                        </div>
                                      </span><span class="em-box">
                                          <i class="fab fa-angular" style="font-size:40px;"></i><br>
                                           Hotels
                                            <div class="em-box-border">
                                              <div class="em-box-border-inner"></div>
                                            </div>
                                          </span>
            
          </div>
        </div>
      </div>
    </section>

   @include('inc.bottom-icons-one') 


@endsection




