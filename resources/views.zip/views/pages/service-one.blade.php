
@extends('layouts.app-two')

@section('page_title')
    SERVICE ONE
@endsection

@section('content')

<section class="bg-img-int bg-pic" style="background-image: url(pilotpublic/images/12.jpg); height: 500px;">

<div class="bg-txt-cnt">
<div class="bg-txt-inner" style="    background-color: rgba(255, 255, 255, 0.9);  ">
    <h1 class="text-center" style="font-weight:700">Royal First Class</h1>
  <p class="text-center">The airline finely selects in-flight facilities to serve passenger needs. Passengers will experience different dishes in Royal First class throughout the flights.</p>
</div>
</div>
</section>

<section class="page-nav-links">
  <div class="container">
    <div class="row">
      <div class="col-md-12 page-nav-links-col">
        <div class="col-md-1 page-nav-links-col-internal">Home <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Serives<i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Service One <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal-current">Current Page</div>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="os14-h1">Find Your Way</div>
      <div class="row">
      <div class="col-md-4">
        <div class="os14-inner">
          <div class="os14-img">
            <img src="pilotpublic/images/gal3.jpg" class="os14-img-1">
          </div>
          <div class="info">
            <div class="info-box">
              <h3>Getting to the Airport</h3>
              <p>Find out how to get to Changi Airport from the city and other parts of Singapore.</p>
              <div class="info-more">
                <a href="#">More </a> <i class="fa fa-arrow-right"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="os14-inner">
          <div class="os14-img">
            <img src="pilotpublic/images/h6.jpg" class="os14-img-1">
          </div>
          <div class="info">
            <div class="info-box">
              <h3>Getting to the Airport</h3>
              <p>Find out how to get to Changi Airport from the city and other parts of Singapore.</p>
              <div class="info-more">
                <a href="#">More </a> <i class="fa fa-arrow-right"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="os14-inner">
          <div class="os14-img">
            <img src="pilotpublic/images/h8.jpg" class="os14-img-1">
          </div>
          <div class="info">
            <div class="info-box">
              <h3>Getting to the Airport</h3>
              <p>Find out how to get to Changi Airport from the city and other parts of Singapore.</p>
              <div class="info-more">
                <a href="#">More </a> <i class="fa fa-arrow-right"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
  </div>
</section>
<br><br><br>
@include('inc.product-one')
@include('inc.text-two')


<section style="background-color: #fbfbfb; padding-bottom:150px; text-align:center;     color: #404040;">
      <br><br>
      <h1><strong> PLANNING FOR YOUR TRIP</strong></h1>

      <div class="container link-card__card-container link-card__card-container-mb ">
            
          <a href="https://www.booking.com/index.html?aid=1183184" target="_blank" class="context-item link-card__item hover--move-up">
              <div class="icon-container">
                  <i class="img-icon icon-new-hotel"></i>
              </div>
              <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                  Book Hotels
              </div>
          </a>
      
          <a href="http://www.changiairport.com/en/airport-guide/facilities-and-services/transit-hotels.html" class="context-item link-card__item hover--move-up">
              <div class="icon-container">
                  <i class="img-icon icon-new-transit_hotel"></i>
              </div>
              <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                  Transit Hotels
              </div>
          </a>
      
          <a href="https://www.rentalcars.com/?affiliateCode=changiairport" target="_blank" class="context-item link-card__item hover--move-up">
              <div class="icon-container">
                  <i class="img-icon icon-new-driving"></i>
              </div>
              <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                  Rent a Car
              </div>
          </a>
      
          <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
              <div class="icon-container">
                  <i class="img-icon icon-new-get_connected_in_sg"></i>
              </div>
              <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                  Rent a WiFi Router
              </div>
          </a>
          <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
            <div class="icon-container">
                <i class="img-icon icon-new-get_connected_in_sg"></i>
            </div>
            <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                Rent a WiFi Router
            </div>
        </a>
        <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
          <div class="icon-container">
              <i class="img-icon icon-new-get_connected_in_sg"></i>
          </div>
          <div class="text-center link-sm-03 text-xs-19 color-custom-4">
              Rent a WiFi Router
          </div>
      </a>


      
  </div>
  </section>


@include('inc.bottom-icons-one')


@endsection




