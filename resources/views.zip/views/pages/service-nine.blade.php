
@extends('layouts.app-two')

@section('page_title')
    SERVICE NINE
@endsection

@section('content')



<section>
  <div style="position: relative; color:white">
    <img src="pilotpublic/images/18.jpg">
    <div style="position: absolute; top:35%; left:25%; color:white; font-size:60px; font-weight:900">OFFERS FROM PILOT & CAR</div>
  </div>
</section>
<section class="page-nav-links">
  <div class="container">
    <div class="row">
      <div class="col-md-12 page-nav-links-col">
        <div class="col-md-1 page-nav-links-col-internal">Home <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Serives<i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal">Service One <i class="fas fa-chevron-right page-nav-links-col-internal-icon"></i></div>
        <div class="col-md-1 page-nav-links-col-internal-current">Current Page</div>
      </div>
    </div>
  </div>
</section>

<br><br><br><br><br><br>
<section class="mt-20">
    <div class="container">
      <div class="row">
        <div class="product-cnt">
          <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMScontent/web/SiteCollectionImages/06-Destinations-World/Bangkok/BKK-floating-market-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMScontent/web/SiteCollectionImages/06-Destinations-World/Los-Angeles/los-angeles-06-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMSContent/web/SiteCollectionImages/05-Destinations-Europe/Moscow/Moscow-02-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
                  <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMScontent/web/SiteCollectionImages/02-Inflight/inflight-couple-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
                  <div class="col-md-4">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMSContent/web/SiteCollectionImages/05-Destinations-Europe/Barcelona/barcelona-01-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 mb-5">
            <div class="product">
              <div class="pr-img">
              <img src="https://www.swiss.com/CMSContent/web/SiteCollectionImages/05-Destinations-Europe/Moscow/Moscow-02-id5.jpg" class="img-fluid">
              </div>
            </div>
            <h1 class="pr-h1">Off to North America</h1>
            <div class="pr-txt">
              <ul class="pr-ul">
                <li><a href="">Chicago<span class="">From CHF 619<i class="fa fa-caret-right"></i></span></a></li>
                <li><a href="">Montreal<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">New York<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">San Fransisco<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">Washington<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
                <li><a href="">More Offers<span class="">From CHF 619<i class="fa fa-caret-right"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <br><br>

  @include('inc.text-two')

  <section class="wrapper os4-wrapper" style="padding:50px 0px 70px 0px ">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="os4-wrap">
              <div class="os4-img-cnt">
                <img src="pilotpublic/images/9.jpg" style="height:300px">
              </div>
              <div class="os4-txt-cnt">
                <h6 class="text-center">Italy</h6>
                <h1 style="color:darkgray">Rome</h1>
                <h5 class="">Discover for yourself</h5>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="os4-wrap">
              <div class="os4-img-cnt">
                <img src="pilotpublic/images/8.jpg" style="height:300px">
              </div>
              <div class="os4-txt-cnt">
                <h6 class="text-center">Italy</h6>
                <h1 style="color:darkgray">Rome</h1>
                <h5 class="">Discover for yourself</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  
  <section style="background-color: #fbfbfb; padding-bottom:150px; text-align:center">
      <br><br>
      <h1><strong> PLANNING FOR YOUR TRIP</strong></h1>

      <div class="container link-card__card-container link-card__card-container-mb ">
            
          <a href="https://www.booking.com/index.html?aid=1183184" target="_blank" class="context-item link-card__item hover--move-up">
              <div class="icon-container">
                  <i class="img-icon icon-new-hotel"></i>
              </div>
              <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                  Book Hotels
              </div>
          </a>
      
          <a href="http://www.changiairport.com/en/airport-guide/facilities-and-services/transit-hotels.html" class="context-item link-card__item hover--move-up">
              <div class="icon-container">
                  <i class="img-icon icon-new-transit_hotel"></i>
              </div>
              <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                  Transit Hotels
              </div>
          </a>
      
          <a href="https://www.rentalcars.com/?affiliateCode=changiairport" target="_blank" class="context-item link-card__item hover--move-up">
              <div class="icon-container">
                  <i class="img-icon icon-new-driving"></i>
              </div>
              <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                  Rent a Car
              </div>
          </a>
      
          <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
              <div class="icon-container">
                  <i class="img-icon icon-new-get_connected_in_sg"></i>
              </div>
              <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                  Rent a WiFi Router
              </div>
          </a>
          <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
            <div class="icon-container">
                <i class="img-icon icon-new-get_connected_in_sg"></i>
            </div>
            <div class="text-center link-sm-03 text-xs-19 color-custom-4">
                Rent a WiFi Router
            </div>
        </a>
        <a href="https://www.changirecommends.com/owifi.aspx" target="_blank" class="context-item link-card__item hover--move-up">
          <div class="icon-container">
              <i class="img-icon icon-new-get_connected_in_sg"></i>
          </div>
          <div class="text-center link-sm-03 text-xs-19 color-custom-4">
              Rent a WiFi Router
          </div>
      </a>


      
  </div>
  </section>
@include('inc.bottom-icons-two')      
    
@endsection




